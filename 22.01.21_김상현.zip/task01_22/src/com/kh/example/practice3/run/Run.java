package com.kh.example.practice3.run;

import com.kh.example.practice3.model.vo.Circle;

public class Run {

	public static void main(String[] args) {
		Circle cir = new Circle();
		
		
		cir.getAreaOfCircle();
		cir.getSizeOfCircle();
		
		cir.incrementRadius();
//		radius++		

		cir.getAreaOfCircle();
		cir.getSizeOfCircle();
	}

}
