package com.kh.practice.list.music.run;

import com.kh.practice.list.music.view.MusicView;

public class Run {

	public static void main(String[] args) {
		MusicView mv = new MusicView();
		
		mv.MainMenu();
	}

}
